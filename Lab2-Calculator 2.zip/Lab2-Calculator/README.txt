Name: Pavel Savvy
SJSU ID: 012452999
SJSU email: pavel.savva@sjsu.edu

Sorry for the late submission. I was not able to generate the .ipa file again because I xCode kept telling me that I need an Admin role on the WINDOWS SPECIALISTS team.

For this lab, I did not implement the “Undo” button, but instead I implemented the undo functionality by swiping right on the main screen.

I variable could be entered by pressing the “->x” button on the empty input, entering variable name, pressing the “return” button on the keyboard and then pressing “=“ button and pressing “=“ button again after entering the desired equation. To use the variable, press “->x” when a constant or a number can be entered and type in variable name. 